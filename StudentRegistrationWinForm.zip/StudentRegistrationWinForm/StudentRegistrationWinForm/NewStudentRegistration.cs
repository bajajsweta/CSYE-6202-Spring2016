﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentRegistrationWinForm
{
    public partial class NewStudentRegistration : Form
    {
        public NewStudentRegistration()
        {
            InitializeComponent();
        }

        private void txt_registerstudentID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
