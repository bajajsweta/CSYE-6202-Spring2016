﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication
{
    /// <summary>
    /// Interaction logic for EditStudent.xaml
    /// </summary>
    public partial class EditStudent : Window
    {

        public event EventHandler editStudent; 
        private List<string> deptType;
        string IDPattern = @"^\d{3}\-?\d{2}\-?\d{4}$";
        public StudentInfo student;

        public EditStudent(StudentInfo student)
        {
            InitializeComponent();
            this.student = student;
            comboBox_deptedit.ItemsSource = fillDeptType();
            loadGroup();
        }

        public void loadGroup()
        {
            maskedtxt_editstudentID.Text = student.StudentID;
            txt_editfirstName.Text = student.StudentFirstName;
            txt_editlastName.Text = student.StudentLastName;
            comboBox_deptedit.Text = student.DeptType;
            if (student.EnrollmentType == "Full Time")
            { rb_editenrollType1.IsChecked = true; }
            else { rb_editenrollType2.IsChecked = true; }
        }

        public List<string> fillDeptType()
        {
            deptType = new List<string>();
            deptType.Add("Informations Systems");
            deptType.Add("International Affairs Systems");
            deptType.Add("Nursing Systems");
            deptType.Add("Pharmacy Systems");
            deptType.Add("Professional Studies Systems");
            return deptType;
        }

        private void button_editStudent_Click(object sender, EventArgs e)
        {
            Regex regex = new Regex(IDPattern);
            bool Matching = regex.IsMatch(maskedtxt_editstudentID.Text);

            if (Matching == false ||
                txt_editfirstName.Text == "" ||
                txt_editlastName.Text == "")
            { System.Windows.MessageBox.Show("Please fill in the empyty fields or Check your ID Number Format"); }
            else {  

                student.StudentID = maskedtxt_editstudentID.Text;
                student.StudentFirstName = txt_editfirstName.Text;
                student.StudentLastName = txt_editlastName.Text;
                student.DeptType = Convert.ToString(comboBox_deptedit.SelectedItem);

                if (rb_editenrollType1.IsChecked == true)
                { student.EnrollmentType = "Full Time"; }
                else { student.EnrollmentType = "Part Time"; }
            

                if (System.Windows.MessageBox.Show("Are you sure you want to update information?",
                    "Update Student", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                    {
                        editStudent(this, student);
                        this.Close();
                    }
                else 
                {
                        this.Close();
                 }
            }
        }

        private void button_cancelStudent_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txt_editfirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void txt_editlastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

    }
}
