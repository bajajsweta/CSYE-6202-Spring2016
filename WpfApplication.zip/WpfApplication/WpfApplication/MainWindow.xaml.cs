﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        private string UserName = "Sweta";
        private string Password = "Sweta";
        private int LoginAttempt = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (txt_username.Text == UserName && masked_txt_password.Password == Password)
            {
                MessageBox.Show("Logged In Successfully");
                this.Hide();
                StudentRegistrationMainWindow studentRegister = new StudentRegistrationMainWindow();
                studentRegister.Closed += (s, args) => this.Close();
                studentRegister.Show();
            }
            else if (LoginAttempt >= 2)
            {
                MessageBox.Show("Invalid Credentials");
                Close();
            }
            else
            {
                MessageBox.Show("Invalid Credentials");
                LoginAttempt++;
            }
        }
    }
}
