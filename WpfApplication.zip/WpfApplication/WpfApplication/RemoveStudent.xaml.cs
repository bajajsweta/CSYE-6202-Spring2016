﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication
{
    /// <summary>
    /// Interaction logic for RemoveStudent.xaml
    /// </summary>
    public partial class RemoveStudent : Window
    {
        public event EventHandler removeStudent;
        public StudentInfo student;
        private List<string> deptType;
        public RemoveStudent(StudentInfo student)
        {
            InitializeComponent();
            this.student = student;
            comboBox_removedept.ItemsSource = fillDeptType();
            loadGroup();
        }

        public List<string> fillDeptType()
        {
            deptType = new List<string>();
            deptType.Add("Informations Systems");
            deptType.Add("International Affairs Systems");
            deptType.Add("Nursing Systems");
            deptType.Add("Pharmacy Systems");
            deptType.Add("Professional Studies Systems");
            return deptType;
        }


        public void loadGroup()
        {
            maskedtxt_removestudentID.Text = student.StudentID;
            txt_removefirstName.Text = student.StudentFirstName;
            txt_removelastName.Text = student.StudentLastName;
            comboBox_removedept.Text = student.DeptType;
            if (student.EnrollmentType == "Full Time")
            { rb_removeenrollType1.IsChecked = true; }
            else { rb_removeenrollType2.IsChecked = true; }
        }


        private void button_addStudent_Click(object sender, EventArgs e)
        {
            if((System.Windows.MessageBox.Show("Are you sure you want to remove?", 
                "Remove Student", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes))
            {
                removeStudent(this, student);
                this.Close();
            }
            else
            {
                this.Close();
            }
        }

        private void button_resetStudent_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void groupBox_registerstudentInfo_Enter(object sender, EventArgs e)
        {

        }

        private void RemoveStudent_Load(object sender, EventArgs e)
        {

        }

    }
}
